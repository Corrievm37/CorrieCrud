<?php
  // DB Params
  define('DB_HOST', '4you.co.za');
  define('DB_USER', 'o4youfqw_corrie');
  define('DB_PASS', 'Lekker@231');
  define('DB_NAME', 'o4youfqw_grud');

  // App Root
  define('APPROOT', dirname(dirname(__FILE__)));
  // URL Root
  define('URLROOT', 'https://4you.co.za/CorrieCrudNew');
  // Site Name
  define('SITENAME', 'Corrie Crud New');
  // App Version
  define('APPVERSION', '1.0.0');